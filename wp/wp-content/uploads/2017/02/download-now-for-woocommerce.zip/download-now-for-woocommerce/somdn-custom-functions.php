<?php
/**
 * DOWNLOAD NOW - WooCommerce - Custom Functions
 * 
 * For users to add their own functions.
 * 
 * @version	1.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** ADD CUSTOM FUNCTIONS BELOW THIS LINE **/