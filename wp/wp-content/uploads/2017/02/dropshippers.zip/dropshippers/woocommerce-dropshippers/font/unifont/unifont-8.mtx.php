<?php
$name='UnifontMedium';
$type='TTF';
$desc=array (
  'Ascent' => 875,
  'Descent' => -125,
  'CapHeight' => 875,
  'Flags' => 4,
  'FontBBox' => '[0 -125 1000 875]',
  'ItalicAngle' => 0,
  'StemV' => 109,
  'MissingWidth' => 500,
);
$up=-117;
$ut=39;
$ttffile=plugin_dir_path( __FILE__ ). '/unifont-8.0.01.ttf';
$originalsize=12291788;
$fontkey='unifont';
?>